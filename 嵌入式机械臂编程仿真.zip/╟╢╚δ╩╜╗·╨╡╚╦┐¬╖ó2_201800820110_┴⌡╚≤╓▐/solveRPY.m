function [a,o,n,a2,o2,n2] = solveRPY(T)
%由位姿解两组RPY
a=atan2(T(2,1),T(1,1));
o=atan2(-T(3,1),(T(1,1)*cos(a)+T(2,1)*sin(a)));
n=atan2((T(1,3)*sin(a)-T(2,3)*cos(a)),(T(2,2)*cos(a)-T(1,2)*sin(a)));

a2=atan2(-T(2,1),-T(1,1));
o2=atan2(-T(3,1),(T(1,1)*cos(a2)+T(2,1)*sin(a2)));
n2=atan2((T(1,3)*sin(a2)-T(2,3)*cos(a2)),(T(2,2)*cos(a2)-T(1,2)*sin(a2)));

a=a*180/pi;
o=o*180/pi;
n=n*180/pi;
a2=a2*180/pi;
o2=o2*180/pi;
n2=n2*180/pi;

end