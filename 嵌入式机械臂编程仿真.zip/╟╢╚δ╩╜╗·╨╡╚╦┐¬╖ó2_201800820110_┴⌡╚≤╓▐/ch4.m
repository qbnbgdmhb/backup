%% 1
clear ; clc; close all;
%�����˲���
d1 = 0;
d2 = 0;

a1 = 1;
a2 = 0.5;

t1 = 10 / 180 * pi;
t2 = 90 / 180 * pi;

L(1)=Link([0      d1      a1      0]);
L(2)=Link([0      d2      a2      0]);
E4=SerialLink(L,'name','e4');
pose_0=[t1,t2];
T0=E4.fkine(pose_0);
figure(1);
E4.plot(pose_0);
  
%%
%ѭ����Ⱥ�ĩ��
D=[0 0.5 0.0 0.0 0.0 0.0];%�ٶ�
pose=pose_0;
poseAll=pose_0;%�洢��
rpy=tr2rpy(T0);
tail=[T0.t(1),T0.t(2),rpy(3)];%�洢ĩ��x��y����z
x = 0.0:0.01:1;
y= T0.t(2)+linspace(0.005,0.5,100);%�˶�����yֵ
X=T0.t(1);
T=T0;
for i = 1:100
T.t(1)=X;
T.t(2)=y(i);
pose=E4.ikine(T, 'mask', [1 1 0 0 0 0],'q0',pose,'lambda',0.001,'rlimit',500,'ilimit',10000);%�����
poseAll=[poseAll;pose];%�洢��
T=E4.fkine(pose);%��ĩ��
rpy=tr2rpy(T);
tail=[tail;[T.t(1),T.t(2),rpy(3)]];
end
figure(2);
E4.plot(pose)
%%
wAll=diff(poseAll)*100;%����ٶ�
aAll=diff(wAll)*100;%���ٶ�
g=9.8;%�������ٶ�
m1=7806*1*0.05*0.05;%����
m2=m1/2;
l1=a1;l2=a2;%�۳�
%��ؽ�����
C2=cos(poseAll(:,2));
C1=cos(poseAll(:,1));
S2=sin(poseAll(:,2));
t0=[1/3*m1*l1^2+m2*l1^2+1/3*m2*l2^2+m2*l1*l2*C2(3), 1/3*m2*l2^2+0.5*m2*l2*l1*C2(3);
    1/3*m2*l2^2+0.5*m2*l2*l1*C2(3), 1/3*m2*l2^2]*aAll(1,:)'+[0,-0.5*m2*l1*l2*S2(3);
    0.5*m2*l1*l2*S2(3),0]*wAll(2,:).^2'+[-m2*l1*l2*S2(3)*wAll(2,1)*wAll(2,2);0]+[(0.5*m1+m2)*g*l1*C1(3)+0.5*m2*l2*g*C1(3)*C2(3);
    0.5*m2*l2*g*C1(3)*C2(3)];%����ѧ����
t=t0';
for i=2:99
t0=[1/3*m1*l1^2+m2*l1^2+1/3*m2*l2^2+m2*l1*l2*C2(i+2), 1/3*m2*l2^2+0.5*m2*l2*l1*C2(i+2);
    1/3*m2*l2^2+0.5*m2*l2*l1*C2(i+2), 1/3*m2*l2^2]*aAll(i,:)'+[0,-0.5*m2*l1*l2*S2(i+2);
    0.5*m2*l1*l2*S2(i+2),0]*wAll(i+1,:).^2'+[-m2*l1*l2*S2(i+2)*wAll(i+1,1)*wAll(i+1,2);0]+[(0.5*m1+m2)*g*l1*C1(i+2)+0.5*m2*l2*g*C1(i+2)*C2(i+2);
    0.5*m2*l2*g*C1(i+2)*C2(i+2)];
t=[t;t0'];
end
%%
figure(1);
%subplot(2,3,1);
plot(x,poseAll(:,1),'--r',x,poseAll(:,2),'--b');
title('�Ƕ�');
figure(2);
%subplot(2,3,2);
plot(x(2:101),wAll(:,1),'r',x(2:101),wAll(:,2),'b');
title('���ٶ�');
figure(3);
%subplot(2,3,3);
plot(x(3:101),aAll(:,1),'r',x(3:101),aAll(:,2),'b');
title('�Ǽ��ٶ�');
figure(4);
%subplot(2,3,4);
plot(x,tail(:,1),'r',x,tail(:,2),'b',x,tail(:,3),'g');
title('x��y��z(rad)');
figure(5);
%subplot(2,3,5);
plot(x(3:101),t(:,1),'r',x(3:101),t(:,2),'b');
title('�ؽ�����');
%% 2
clc
clear 
close all
deg = pi/180;

L(1)= Revolute('d', 0, 'a', 4, 'alpha', 0, ...
    'm', 20,...%����
    'r',[-2,0,0]);%����

L(2) = Revolute('d', 0, 'a', 3, 'alpha', 0, ...
    'm', 15,...
    'r',[-1.5,0,0]);

L(3) = Revolute('d', 0, 'a', 2, 'alpha', 0, ...
    'm', 10,...
    'r',[-1,0,0]);
%L(4) = Revolute('d', 0, 'a', 2, 'alpha', 0,'modified', ...
  %  'm', 10,...
  %  'r',[-1,0,0]);

robot=SerialLink(L,'name','E42','gravity',[0,9.81,0]);
%robot.teach();
theta=[10,20,30]*deg;
w=[1,2,3];%���ٶ�
a=[0.5,1,1.5];%�Ǽ��ٶ�
T = robot.rne(theta,w,a);%������

%% 3
clc
clear 
close all
deg = pi/180;

L(1)= Revolute('d', 0, 'a', 4, 'alpha', 0, ...
    'm', 20,...%����
    'I',[0,0,0.5],...%����
    'r',[-2,0,0]);%����

L(2) = Revolute('d', 0, 'a', 3, 'alpha', 0, ...
    'm', 15,...
    'I',[0,0,0.2],...
    'r',[-1.5,0,0]);

L(3) = Revolute('d', 0, 'a', 2, 'alpha', 0, ...
    'm', 10,...
    'I',[0,0,0.1],...
    'r',[-1,0,0]);
%L(4) = Revolute('d', 0, 'a', 2, 'alpha', 0,'modified', ...
%    'm', 10,...
%    'I',[0,0,0.1]);
robot=SerialLink(L,'name','E43','gravity',[0,9.81,0]);
%robot.plot([-60,90,30]*deg);
%myftfun=[20,5,1]; ,'q0',[-60,90,30]*deg,'qd0',[0,0,0]

%��ʼ�ȣ���ʼ���ٶȣ����ء���ȣ����ٶ�
[T,q,qd] = robot.fdyn(4,@myftfun,[-60,90,30]*deg,[0,0,0],[20,5,1]);
figure(1);
subplot(1,2,1);
plot(T,q(:,1),'--r',T,q(:,2),'--b',T,q(:,3),'--g');
title('�Ƕ�');
subplot(1,2,2);
plot(T,qd(:,1),'--r',T,qd(:,2),'--b',T,qd(:,3),'--g');
title('���ٶ�');

