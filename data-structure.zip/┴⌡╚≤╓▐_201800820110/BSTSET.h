#ifndef _BSTSET_H_
#define _BSTSET_H_

using namespace std;

template<typename E>
class Visitor;

template<typename E>
class BSTNode{
public:
    E _ele;
    BSTNode *_lchild;
    BSTNode *_rchild;
    BSTNode *_parent;
    
    BSTNode(E ele ,BSTNode *lchild,BSTNode *rchild,BSTNode *parent):
    _ele(ele),_lchild(lchild),_rchild(rchild),_parent(parent){};
    
//    int degree(){
//    	int ret = 0;
//        if (_lchild != NULL) ret++;
//        if (_rchild != NULL) ret++;
//        return ret;
//	}
};

template<typename E>
class BSTSet{
private:
    BSTNode<E> *_Root ;
    int Size;

public:
    BSTSet():_Root(NULL){Size=0;};//���� 
    ~BSTSet(){};
    int size();
    bool isEmpty();
	void clear();
	void add(const E &ele);
	void remove(const E &ele);
	bool contains(const E &ele) const;
	void traversal(Visitor<E>* const visitor) const;
	BSTNode<E>* sucessor(BSTNode<E>* const node) const; //���Һ��
private:
	//�ڲ��ӿ� 
    void add(BSTNode<E>* &root,BSTNode<E>* z);
    void remove(BSTNode<E>* &root, BSTNode<E> *z);
    void clear(BSTNode<E>*& root);
    BSTNode<E>* find(BSTNode<E>* const &root,const E &ele) const;
    void traversal(BSTNode<E>* const &root, Visitor<E>* const visitor) const;
};

template <typename E>
int BSTSet<E>::size(){
	return Size;
}

template <typename E>
bool BSTSet<E>::isEmpty(){
	return Size==0;
}

template <typename E>
void BSTSet<E>::add(const E &ele)
{
    BSTNode<E>* z= new BSTNode<E>(ele,NULL,NULL,NULL);
    if(!z) //����ʧ��
        return ;
    //�ڲ��������� 
    add(_Root,z);
}

template<typename E>
void BSTSet<E> ::add(BSTNode<E>* &root,BSTNode<E>* z)
{
    BSTNode<E>* parent = NULL;
    BSTNode<E>* temp = root;
    //Ѱ�Ҹ��ڵ� 
    while(temp!=NULL)
    {
        parent= temp;
        if(z->_ele==temp->_ele) //�Ѵ������������� 
        	return ;
        else if(z->_ele>temp->_ele)
            temp= temp->_rchild;
        else 
            temp=temp->_lchild;
    }
    z->_parent = parent;
    if(parent==NULL) //�����������ڵ�
        root = z;
    else if(z->_ele>parent->_ele)
        parent->_rchild = z;
    else                          
        parent->_lchild = z;
    Size++;
}

template <typename E>
bool BSTSet<E>::contains(const E &ele) const
{
    return find(_Root,ele)!=NULL;
}

template <typename E>
BSTNode<E>* BSTSet<E>::find(BSTNode<E>* const &root,const E& ele) const
{//Ѱ�Ҳ����ؽڵ� 
    BSTNode<E>* temp = root;
    while(temp != NULL)
    {
        if(temp->_ele == ele)
            return temp;
        else if(temp->_ele>ele)
            temp = temp->_lchild;
        else
            temp = temp->_rchild;
    }
    return NULL;
}

template<typename E>
void BSTSet<E>::traversal(Visitor<E>* const visitor)const
{
    traversal(_Root,visitor);
}

template<typename E>
void BSTSet<E>::traversal(BSTNode<E>* const &root ,Visitor<E>* const visitor)const
{//������� 
	if (root == NULL) return;
	
	traversal(root->_lchild,visitor);
	visitor->visit(root);
	traversal(root->_rchild,visitor);

}

template <typename E>
BSTNode<E>* BSTSet<E>::sucessor(BSTNode<E>* const node)const
{//��� 
	//1.�ҵ����� 
    BSTNode<E>* cur = node->_rchild;
    if (cur != NULL) { // ���ӽڵ㲻ΪNULL
        while (cur->_lchild != NULL) {
            cur = cur->_lchild;
        }
        return cur;
    }
    //2.�Ӹ��ڵ㡢�游�ڵ���Ѱ�Һ��
	cur=node;
    while (cur->_parent != NULL && cur == cur->_parent->_rchild) {
        cur = cur->_parent;
    }
    return cur->_parent;
}

template<typename E>
void BSTSet<E>::remove(const E &ele)
{
    BSTNode<E> *node; 
    //�ҵ��ڵ� 
    if ((node = find(_Root, ele)) != NULL)
    	//ɾ�� 
        remove(_Root, node);
}

template <class E>
void BSTSet<E>::remove(BSTNode<E>* &root, BSTNode<E> *node)
{
    BSTNode<E> *x=NULL;
    BSTNode<E> *y=NULL;
//    int degree = root.degree();
	//yΪɾ���ڵ㱾�����̣�Ϊʵ�ʻ����ڴ�Ľڵ� 
    if ((node->_lchild == NULL) || (node->_rchild == NULL))
    	//�� < 2 
        y = node;
    else
    	//�� ==2���Һ�̣����ͬ���� < 2 
        y = sucessor(node);
    
    //y�� < 2��ɾ�����ؽ����Ӽ��� 
	//xΪy���󺢡��Һ���� 
    if (y->_lchild != NULL)
        x = y->_lchild;
    else
        x = y->_rchild;
	//x�ǿգ����� 
    if (x != NULL)
        x->_parent = y->_parent;
	
    if (y->_parent == NULL)
    	//y�Ǹ���ɾ����x���� 
        root = x;
    else if (y == y->_parent->_lchild)
    	//��������x 
        y->_parent->_lchild = x;
    else
        y->_parent->_rchild= x;
        
    //node�� ==2��ɾ����̵���� 
    if (y != node) 
        node->_ele = y->_ele;

  	delete y;
  	y=NULL;
    Size--;
}

template<typename E>
void BSTSet<E>::clear()
{
    clear(_Root);
    Size=0;
}

template<typename E>
void BSTSet<E>::clear(BSTNode<E>*& root)
{
    if(root->_lchild!=NULL)
        clear(root->_lchild);
    if(root->_rchild!=NULL)
        clear(root->_rchild);
    if(root->_lchild==NULL&&root->_rchild==NULL)
    {
        delete root;
        root = NULL;
    }
}

#endif
