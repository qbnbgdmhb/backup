//����+����ʵ��map 
#include <iostream>
#include <string>
#include"Map.h"
using namespace std;

class HashCode
{//�Զ���ϣ���� 
public:
	// BKDR Hash Function
    int operator()(const string &key)
    {
    int seed = 131;
	int hash = 0;
	const char *str = key.c_str();
    while (*str)
	{
		hash = hash * seed + (*str++);
	}
	return (hash & 0x7FFFFFFF);
    }
};

class EqualKey
{//�Զ�key�ȽϺ��� 
public:
    bool operator()(const string & A, const string & B)
    {
        if (A.compare(B) == 0)
            return true;
        else
            return false;
    }
};

template<class K, class V>
class Visitor
{//�Զ������� 
public:
//    void visit(Map<K, V, HashCode, EqualKey> * map) 
    void visit(MapNode<K, V>* const &node)
	{//��ӡnode
		cout<<node->_key<<":"<<node->_value<<";";
	};
};


int main()
{
    Map<string, string, HashCode, EqualKey> map;//���ⳤ�����飬Ĭ��16 
//	cout << map.size()<< endl;
	cout << "=============PUT============="<< endl;
    cout << map.put("", "NULL")<< endl;  //���ܿ�ֵ �ַ���""��0���ƶ�Ӧ�������� 
    cout << map.put("lv", "gren")<< endl; 
    cout << map.put("lv", "green")<< endl;
    cout << map.put("hong", "red")<< endl;
    cout << map.put("lan", "blue")<< endl;
    cout << map.put("feng", "wind")<< endl;
    cout << "��ǰ��������"<<map.size()<<endl;
	cout << "==========TRAVERSAL=========="<< endl;
	Visitor<string, string>* iterator;
	cout << "("<<map.size()<<")"<<"{";
	map.traversal(iterator);
	cout << "}"<<endl;
	cout << "============REMOVE============"<< endl;
    cout << "remove key==feng: "<<map.remove("feng")<< endl;
    cout << "remove key==lv: "<< map.remove("lv")<< endl;
    cout << "remove key==123: "<< map.remove("123")<< endl;//���ؿ�ֵ 
    cout << "remove key==: "<< map.remove("")<< endl;
	cout << "("<<map.size()<<")"<<"{";
	map.traversal(iterator);
	cout << "}"<<endl;
//	cout << "============CLEAR============"<< endl;
//    map.clear();
//    cout << "��ǰ��������"<< map.size()<<"; �Ƿ�Ϊ�գ�"<<map.isEmpty()<< endl;
    
//    map.put("lv", "green"); 
//    map.put("hong", "red");
    map.put("zui", "mouth");
	cout << "=============GET============="<< endl;
    cout << "get key==123: "<< map.get("123")<< endl;//���ؿ�ֵ 
	cout << "get key==lan: "<< map.get("lan")<< endl;
	cout << "get key==zui: "<< map.get("zui")<< endl;
	cout << "===========CONTAINS==========="<< endl;
	cout << "����key==123��"<<map.containsK("123")<<"; ����key==hong��"<<map.containsK("hong")<< endl;
	cout << "����value==gren��"<<map.containsV("gren")<<"; ����value==green��"<<map.containsV("green")<< endl;
	cout << "============CLEAR============"<< endl;
	map.clear();
	cout << "��ǰ��������"<< map.size()<<"; �Ƿ�Ϊ�գ�"<<map.isEmpty()<< endl;
	
	cout << "\n========ValueΪdouble========"<< endl;
    Map<string, double, HashCode, EqualKey> map2(2);
    cout << map2.put("ran", 823)<< endl; 
    cout << map2.put("ying", 211)<< endl;
    cout << map2.put("qin", 816)<< endl;
    cout << map2.put("yuan", 822)<< endl;
    cout << map2.remove("yuan")<< endl;
    cout << map2.get("ying")<< endl;
    Visitor<string, double>* iterator2;
	cout << "("<<map2.size()<<")"<<"{";
	map2.traversal(iterator2);
	cout << "}"<<endl;
	try {
		Map<string, double, HashCode, EqualKey> map(-2);
   	}catch (const char* msg) {
   		cerr << msg << endl;
   }
	
    return 0;
}
