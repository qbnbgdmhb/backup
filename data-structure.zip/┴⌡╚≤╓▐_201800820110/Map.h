#ifndef _MAP_H_
#define _MAP_H_
//#define int unsigned int
#define DEFAULT_SIZE 16

using namespace std;

template<class K, class V>
class Visitor;

template<class K, class V>
class MapNode
{
public:
    K  _key;
    V  _value;
    MapNode *next;

    MapNode(K key, V value)
    {
        _key = key;
        _value = value;
        next = NULL;
    }
    ~MapNode(){}
//    MapNode& operator=(const MapNode& node)
//    {//����= 
//        _key  = node._key;
//        _value = node._value;
//        next = node.next;
//        return *this;
//    }
};


template <class K, class V, class HashCode, class EqualKey>
class Map
{
public:
    Map(int size=DEFAULT_SIZE);//Ĭ��16 
    ~Map(){};		//���� 
    int size();
	bool isEmpty();
    void clear();	//��� 
    V& put(const K& key, const V& value);
    V& get(const K& key);
    V remove(const K& key);
    bool containsK(const K& key);
	bool containsV(const V& value) const;
	void traversal(Visitor<K,V>* const v) const;//visitor�ӿ� 

private:
	int dataSize; //data����
    int listSize;	//list����
    MapNode<K, V> **list;	//�洢���� ��ֹ�ⲿֱ�ӷ��� 
    V VNULL;	//��ֵ 
    HashCode hash;
    EqualKey equalKey;
	void traversal(MapNode<K, V>** const &list, Visitor<K,V>* const v) const;//visitor�ڲ��ӿ� 
//	void keyNullCheck(const K& key) const;
//	void valueNullCheck(const V& value) const;
};

//template <class K, class V, class HashCode, class EqualKey>
//void Map<K, V, HashCode, EqualKey>::keyNullCheck(const K& key) const
//{
//	if(key.empty()){
//		throw "Key NULL Error";
//	}
//};

//template <class K, class V, class HashCode, class EqualKey>
//void Map<K, V, HashCode, EqualKey>::valueNullCheck(const V& value) const
//{
//	if(value.empty()){
//		throw "Value NULL Error";
//	}
//};
template <class K, class V, class HashCode, class EqualKey>
void Map<K, V, HashCode, EqualKey>::traversal(MapNode<K, V>** const &list, Visitor<K,V>* const v) const
{
	{//����map 
		MapNode<K, V> * node;
		for (int i = 0; i < listSize; i++){
		node = list[i];
		while(node!=NULL){
			v->visit(node);
			node=node->next;
		}
	}
	};
}

template <class K, class V, class HashCode, class EqualKey>
void Map<K, V, HashCode, EqualKey>::traversal(Visitor<K,V>* const v) const
{
//	v->visit(this);
	traversal(list, v);
}

//���� 
template <class K, class V, class HashCode, class EqualKey>
Map<K, V, HashCode, EqualKey>::Map(int size) : listSize(size),hash(),equalKey()
{
	if (listSize<=0){
		throw "Init Size Error";
//		return;
	}
		
	dataSize=0;
    list = new MapNode<K, V>*[listSize];
    for (unsigned i = 0; i < listSize; i++)
        list[i] = NULL;

}
//���� 
//template <class K, class V, class HashCode, class EqualKey>
//Map<K, V, HashCode, EqualKey>::~Map()
//{
//    for (int i = 0; i < listSize; i++)
//    {
//        MapNode<K, V> *currentNode = list[i];
//        while (currentNode)
//        {
//            MapNode<K, V> *next=currentNode->next;
//            delete currentNode;
//            currentNode = next;
//        }
//        list[i]=NULL;
//    }
//    delete[] list;
//    listSize=0;
//    dataSize=0;
//}

template <class K, class V, class HashCode, class EqualKey>
void Map<K, V, HashCode, EqualKey>::clear()
{
	if(dataSize==0)
		return;
		
	MapNode<K, V> *currentNode, *next=NULL;
    for (int i = 0; i < listSize; i++)
    {
        currentNode = list[i];
        while (currentNode)
        {
        	next =currentNode->next;
            delete currentNode;
            currentNode = next;
        }
        list[i]=NULL;
    }
    delete[] list;
    listSize=0;
    dataSize=0;
}

template <class K, class V, class HashCode, class EqualKey>
int Map<K, V, HashCode, EqualKey>::size()
{
    return dataSize;
}

template <class K, class V, class HashCode, class EqualKey>
bool Map<K, V, HashCode, EqualKey>::isEmpty()
{
    return dataSize==0 ;
}

template <class K, class V, class HashCode, class EqualKey>
V& Map<K, V, HashCode, EqualKey>::put(const K& key, const V& value)
{
//	keyNullCheck(key);
//	valueNullCheck(value);
    int index = hash(key)%listSize;
    MapNode<K, V> * node=NULL;

	if (list[index]== NULL) {
        dataSize++;
        node = new MapNode<K, V>(key,value);
        // ��ַΪ��ֱ�Ӵ洢
        list[index]=node;
    }
    else {

        node = list[index];
        while (node != NULL) {
            if (equalKey(key, node->_key)) {
                // �Ѿ�����ֱ�Ӹ���
                node->_value = value;
                return node->_value;
            }
            node = node->next;
        };

        // ������ͻͷ��
        node = new MapNode<K, V>(key,value);
        node->next = list[index];
        list[index] = node;
        dataSize++;
    }

    return node->_value;
}

template <class K, class V, class HashCode, class EqualKey>
V Map<K, V, HashCode, EqualKey>::remove(const K& key)
{
//	keyNullCheck(key);
	if (dataSize==0){return VNULL;}
    int index = hash(key) % listSize;
	if (list[index]==NULL){return VNULL;}

    MapNode<K, V> * node = list[index];
	V result;
    if (equalKey(node->_key, key)) {
        dataSize--;
        result=node->_value;
        if (node->next == NULL) {
        	//�ҵ����޺�� 
            list[index]=NULL;
            //�ռ������������ͷ� 
        }
        else {
        	//�ҵ����к�� 
            list[index]=node->next;
            delete node;
            node=NULL;
        }
        return result;
    }
    else {
    	//����Ѱ�� 
    	MapNode<K, V> * prev = node;
        node = node->next;
        while (node != NULL) {
            if (equalKey(node->_key, key)) {
                dataSize--;
                result = node->_value;
                prev->next = node->next;
                delete node;
            	node=NULL;
                return result;
            }
            prev = node;
            node = node->next;
        };
    }
    //δ�ҵ����ؿ� 
    return VNULL;
}


template <class K, class V, class HashCode, class EqualKey>
V& Map<K, V, HashCode, EqualKey>::get(const K& key)
{
//	keyNullCheck(key);
	//�����index 
    int  index = hash(key) % listSize;
    if (list[index] == NULL)
        return VNULL;
    else
    {//�������� 
        MapNode<K, V> * node = list[index];
        while (node)
        {
        	if (equalKey(node->_key, key)){
        		return node->_value;
			}
            node=node->next;
        }
        return VNULL;
    }
}

template <class K, class V, class HashCode, class EqualKey>
bool Map<K, V, HashCode, EqualKey>::containsK(const K& key)
{
//	keyNullCheck(key);
    int  index = hash(key) % listSize;
    if (list[index] == NULL) {return false;}
    MapNode<K, V> * node = list[index];
    if (equalKey(node->_key, key)) {return true;}
    if (node->next != NULL) {
        do {
            if (equalKey(node->_key, key)) {
                return true;
            }
            node = node->next;

        } while (node != NULL);
        return false;
    }
    else {
        return false;
    }
}

template <class K, class V, class HashCode, class EqualKey>
bool Map<K, V, HashCode, EqualKey>::containsV(const V& value)const
{	
//	valueNullCheck(value);
	//����Ѱ��value 
	for (int i = 0; i < listSize; i++){
		MapNode<K, V> * node = list[i];
		if (node!=NULL){
			if (node->_value==value){
				return true;
			}
			if (node->next != NULL) {
        do {
            if (node->_value==value) {
                return true;
            }
            node = node->next;

        } while (node != NULL);
        return false;
    }
    else {
        return false;
    }
		}
	}
}

#endif
