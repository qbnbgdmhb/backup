
import time
import numpy as np
import gurobipy as gp
from gurobipy import GRB
import cvxpy as cp
import pulp
from scipy.optimize import linprog


print('gurobi:')

# time_start=time.time()
try:
    m = gp.Model("3.4_1")

    x = m.addMVar(shape=2, name="x")

    obj = np.array([4, 1])
    m.setObjective(obj @ x, GRB.MINIMIZE)

    m.addConstr(3*x[0] +x[1] ==3, "c0")
    m.addConstr(4*x[0] +3*x[1] >= 6, "c1")
    m.addConstr(x[0] + 2* x[1] <= 4, "c2")
    m.addConstrs((x[i] >=0 for i in range(2)), name='c')
    time_start = time.time()
    m.optimize()
    time_end = time.time()

    for v in m.getVars():
        print('%s %g' % (v.varName, v.x))

    print('Obj: %g' % m.objVal)

except gp.GurobiError as e:
    print('Error code ' + str(e.errno) + ': ' + str(e))

except AttributeError:
    print('Encountered an attribute error')
# time_end=time.time()
print('gurobi cost',time_end-time_start)


print()
print('cvx:')
np.random.seed(1)
# time_start=time.time()
A=cp.Parameter(
    shape=(1,2),
               # boolean=True,
               # integer=True
               )
A.value = np.array([[4,1]])
x = cp.Variable(2)
objective = cp.Minimize(cp.sum(A@x))
constraints = [
    0 <= x,
    3*x[0] +x[1] ==3,
    4*x[0] +3*x[1] >= 6,
    x[0] + 2* x[1] <= 4
]
prob = cp.Problem(objective, constraints)
print(prob.is_dcp)
time_start=time.time()
result = prob.solve(cp.SCS)
time_end=time.time()
print(prob.status)
print('min ',prob.value)
print('x ',x.value)
print('cvx default scs cost',time_end-time_start)

prob_ = cp.Problem(objective, constraints)
time_start=time.time()
prob_.solve(cp.GUROBI)
time_end=time.time()
print(prob_.status)
print('min ',prob_.value)
print('x ',x.value)
print('cvx using gurobi cost',time_end-time_start)


print()
print('pulp:')
x1 = pulp.LpVariable("x1", 0)
x2 = pulp.LpVariable("x2", 0)

prob3=pulp.LpProblem(name='3.4_1', sense=pulp.LpMinimize)
prob3 += 4*x1 + x2

prob3 += 3*x1 + x2 == 3
prob3 += 4*x1 + 3*x2 >= 6
prob3 += x1 + 2*x2 <=4

time_start=time.time()
prob3.solve(
    pulp.GUROBI(msg = 0)
           )
time_end=time.time()

print("Status:", pulp.LpStatus[prob3.status])

for v in prob3.variables():
    print(v.name, "=", v.varValue)

print("min = ", pulp.value(prob3.objective))
print('pulp using gurobi cost',time_end-time_start)

prob4=pulp.LpProblem(name='3.4_1', sense=pulp.LpMinimize)
prob4 += 4*x1 + x2

prob4 += 3*x1 + x2 == 3
prob4 += 4*x1 + 3*x2 >= 6
prob4 += x1 + 2*x2 <=4

time_start=time.time()
prob4.solve()
time_end=time.time()

print("Status:", pulp.LpStatus[prob3.status])

for v in prob4.variables():
    print(v.name, "=", v.varValue)

print("min = ", pulp.value(prob4.objective))
print('pulp using cbc cost',time_end-time_start)


print()
print('scipy..linprog:')
c = [4, 1]
A_eq=[[3, 1]]
b_eq=[3]
A_ub = [[-4, -3],[1,2]]
b_ub = [-6,4]
x0_bounds = (0, None)
x1_bounds = (0, None)
time_start=time.time()
res = linprog(c, A_eq=A_eq, b_eq=b_eq,A_ub=A_ub, b_ub=b_ub, bounds=(x0_bounds, x1_bounds),
              options={"disp": True})
time_end=time.time()
print(res)
print('linprog cost',time_end-time_start)

