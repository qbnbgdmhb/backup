
import numpy as np


class simplex:
    def __init__(self,method):
        # 0 未得到最优解
        # 1 无解
        # 2 最优解
        # 3 无界
        self.status = 0
        # self.inVar = None        #保留输出用
        # self.outVar = None
        self.method=method
        self.is2p=0

    def standardization(self,A_eq,A_mt,A_lt, b, c,z0):  #转系数矩阵为初始矩阵
        self.b=b
        self.eq=len(A_eq);self.lt=len(A_lt);self.mt=len(A_mt);self.lenc=c.shape[1]
        self.m = self.eq + self.lt + self.mt
        self.n =self.m+self.mt+self.lenc
        self.A=np.zeros((self.m,self.n))

        if self.eq>0:
            self.is2p=1
            self.A[:self.eq,:self.lenc]=A_eq

        if self.mt>0:
            self.is2p = 1
            Z = -np.identity(self.mt)
            A_mt = np.append(A_mt, Z, axis=1)
            self.A[self.eq:self.eq + self.mt, :self.lenc + self.mt] = A_mt

        if self.lt>0:
            self.A[-self.lt:,:self.lenc]=A_lt

        Z = np.identity(self.m)
        self.A[:,-self.m:]=Z
        self.c=np.append(c,np.zeros(self.n-self.eq-self.mt-self.lenc))
        self.z0=z0

        self.base=self.find_base(self.A)
        self.R=list(range(self.n-self.m, self.n-self.lt))
        if self.is2p==1:
            self.cc=self.c
            self.c=np.zeros(self.n)
            for r in self.R:
                self.c[r]=1


    def set_para(self, A, b, c, base, z0):
        self.A = A
        self.b = b
        self.c = -c
        self.base = base
        self.m, self.n = self.A.shape
        self.z0 = z0

    def find_base(self,A):
        base=[]
        for col in range(A.shape[1]):
            sumcol=0
            for row in range(A.shape[0]):
                if (A[row,col]!=0.0 and A[row,col]!=1.0):
                    sumcol=0
                    break
                sumcol+=A[row,col]
            if sumcol==1:
                base.append(col)
        return base

    def int_table(self):
        self.table = np.zeros((self.m + 1, self.n + 1))
        self.table[1:, -1:] = self.b.T
        self.table[0, -1] = self.z0
        self.table[1:, :-1] = self.A
        self.table[0, :-1] = -self.c

        self.baseVar = self.base
        self.xx = np.zeros((1, self.n), dtype=np.int)
        self.xx[:1, 0:]  = list(range(1, int(self.n + 1)))    #制表第一行

    def show(self):
        # 第一行
        print('|', end=' ')
        print('%-3s' % ("基") + " " + "|", end=' ')
        for y1 in range(self.n):
            print('    ' + 'x%d' % self.xx[0, y1], end=' ')
            print('|', end=' ')
        print('%-5s' % (" 解") + " " + "|", end='')
        print()
        # 制表
        base = ['z']
        base += list(map(lambda n: n+1 , self.baseVar))
        for i in range(self.m + 1):
            print('|', end=' ')
            if type(base[i]) == int:
                print('%1s%-2d' % ('x', base[i]), end='')
            else:
                print(base[i], end='  ')
            print('  |', end=' ')
            for j in range(self.n + 1):
                print('%6.2f' % self.table[i, j], end=' ')
                print('|', end=' ')
            print()
        print()


    def is_best(self):
        sigma = self.table[0,:-1]
        for i in self.baseVar:
            sigma[i] = 0

        if self.method=='max':
            if np.min(sigma)<0:
                return False
            else:
                self.status = 2
                return True
        elif self.method=='min':
            if np.max(sigma) > 0.0000001:
                return False
            else:
                self.status = 2
                return True

    def is_no_solution(self):
        for sigma_index in range(self.n):
            if sigma_index not in self.baseVar:
                sigma = self.table[0, sigma_index]
                if self.method=='max':
                    if sigma < 0:
                        no_solution_flag = True
                        for a in self.table[1:, sigma_index]:
                            if a > 0:
                                no_solution_flag = False
                        if no_solution_flag == True:
                            self.status = 3
                            return True
                if self.method=='min':
                    if sigma > 0:
                        no_solution_flag = True
                        for a in self.table[1:, sigma_index]:
                            if a > 0:
                                no_solution_flag = False
                        if no_solution_flag == True:
                            self.status = 3
                            return True
        return False

    def update(self):
        #1 非基找最小/大
        sigma=self.table[0,:-1]
        for i in self.baseVar:
            sigma[i]=0
        if self.method == 'max':
            inVar = int(np.argmin(sigma))
        elif self.method=='min':
            inVar = int(np.argmax(sigma))

        #2 出基找比值最小
        rates=[]
        for row in range(1,self.m+1):
            a = self.table[row, inVar]
            b = self.table[row, -1]
            if a > 0:
                rate=float(b / a)
                rates.append([rate,row])
        outVar= min(rates)[1]-1     #最小比值的index

        #3 更新table
        a = self.table[outVar+1, inVar]
        self.table[outVar+1, :] /= a
        for i in range(self.m + 1):
            if i != outVar+1:
                self.table[i, :] -= self.table[outVar+1, :] * self.table[i, inVar]
        self.baseVar[outVar] = inVar


    def base_to_zero(self):
        k=0
        for col in self.baseVar:
            a=self.table[0,col]
            if a!=0:
                if k==0:
                    self.show()
                    k=1
                row=self.baseVar.index(col)
                b=self.table[row+1,col]
                rate=a/b
                self.table[0,:]-=self.table[row+1,:]*rate


    def solve_1p(self):
        self.int_table()
        self.base_to_zero()

        while 1:
            self.show()
            if self.is_best() or self.is_no_solution():
                return
            self.update()

    def solve_2p(self):
        print('一阶段')
        sss=simplex('min')
        sss.set_para(self.A,self.b,-self.c,self.base,self.z0)
        sss.solve_1p()
        if sss.table[0,-1]>0:
            sss.status=1
            return
        else:
            R = self.R
            A = np.delete(sss.table, R, axis=1)[1:,:-1]
            b=np.array([sss.table[1:,-1]])
            c=self.cc
            base=self.find_base(A)
            self.set_para(A,b,-c,base,0)

            print('二阶段')
            self.solve_1p()

    def solve(self):
        if self.is2p==0:
            self.solve_1p()
        elif self.is2p==1:
            self.solve_2p()


    def result(self):
        if self.status == 1:
            print("此题无解")
        elif self.status == 2:
            print("此题有最优解")
        elif self.status==3:
            print('此题无界')
        base = ['z']
        base += list(map(lambda n: n + 1, self.baseVar))
        for i in range(self.m + 1):
            print('|', end=' ')
            if type(base[i]) == int:
                print('%1s%-2d' % ('x', base[i]), end='')
            else:
                print(base[i], end='  ')
            print('  |', end=' ')
            print('%6.2f' % self.table[i, -1], end=' ')
            print('|', end=' ')
            print()
        print()



if __name__ == "__main__":

    '''
    A_eq=[[等式约束系数]]
    A_mt=[[>=约束系数]]
    A_lt=[[<=约束系数]]
    b=[[约束值按(等式、>=、<=)序排列]]
    c=[[目标方程系数]]
    standardization为标准化函数，也可使用set_para直接输入初始矩阵
    格式：set_para(A,b,-c,base,z0)
    
    程序自行判断二阶法
    可分别无界和二阶段无解的情况
    '''

    print('Q1')
    s1 = simplex('max')  #申请一个求解max的单纯形

    A_eq = np.array([])    #添加格式为[a,b]
    A_mt = np.array([])
    A_lt=np.array([[6,4],
                   [1,2],
                  [-1,1],
                  [0,1]])


    b = np.array([[24,6,1,2]])  #按序排列
    c = np.array([[5,4]])
    s1.standardization(A_eq,A_mt,A_lt,b,c,0)
    s1.solve()
    s1.result()


    print('Q2')
    s2 = simplex('min')
    A_eq = np.array([[3,1]])
    A_mt = np.array([[4,3]])
    A_lt = np.array([[1,2]])

    b = np.array([[3,6,4]])
    c = np.array([[4,1]])

    s2.standardization(A_eq,A_mt,A_lt,b,c,0)
    s2.solve()
    s2.result()

    print('Q3')
    s3=simplex('max')
    A_eq = np.array([])
    A_mt = np.array([])
    A_lt = np.array([[1, -1],
                     [2,0]])

    b = np.array([[10,40]])
    c = np.array([[2,1]])

    s3.standardization(A_eq, A_mt, A_lt, b, c, 0)
    s3.solve()
    s3.result()
